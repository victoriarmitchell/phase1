import os
import numpy as np
import pandas as pd
import joblib
from google.cloud import storage  # Add this for GCS upload
from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report

# Parse command-line arguments
parser = argparse.ArgumentParser()
parser.add_argument("--bucket", type=str, required=True, help="GCS bucket to save the model")
args = parser.parse_args()

# Get the GCS bucket from environment variables
BUCKET_NAME = os.getenv("BUCKET_NAME", "gs://phase1gcp")  # Default to your bucket

# Generate synthetic fraud detection data
X, y = make_classification(
    n_samples=1000,
    n_features=20,
    n_informative=5,
    n_redundant=2,
    n_clusters_per_class=1,
    weights=[0.95, 0.05],  # 5% fraud cases
    random_state=42
)

# Convert to Pandas DataFrame
df = pd.DataFrame(X, columns=[f'feature_{i}' for i in range(20)])
df['label'] = y

# Split the data
X_train, X_test, y_train, y_test = train_test_split(df.drop("label", axis=1), df["label"], test_size=0.2, random_state=42)

# Train a Logistic Regression model
model = LogisticRegression(solver="liblinear")
model.fit(X_train, y_train)

# Save the trained model locally first
local_model_path = "models/fraud_model.pkl"
os.makedirs("models", exist_ok=True)
joblib.dump(model, local_model_path)

print(f"Model training complete. Saved locally to {local_model_path}")

# **Upload the trained model to GCS**
def upload_to_gcs(local_path, gcs_path):
    storage_client = storage.Client()
    bucket = storage_client.bucket(BUCKET_NAME.replace("gs://", ""))  # Remove `gs://`
    blob = bucket.blob(gcs_path)
    blob.upload_from_filename(local_path)
    print(f"Uploaded {local_path} to {gcs_path}")

# Set the Cloud Storage path
gcs_model_path = f"{BUCKET_NAME}/models/fraud_model.pkl"

# Upload to GCS
upload_to_gcs(local_model_path, gcs_model_path)